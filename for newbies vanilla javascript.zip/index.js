// const daysOfWeek = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun", true];

// console.log(daysOfWeek);

// console.log(daysOfWeek[2]);
// console.log(daysOfWeek[0]);
// console.log(daysOfWeek[432]);

// const foxInfo = {
//   name : "Firefox",
//   age: 1000,
//   gender: "Fire",
//   isHandsome: true
// }

// foxInfo = true;

// console.log(foxInfo.gender);

// foxInfo.gender = "Female";

// console.log(foxInfo.gender);


// const foxInfo = {
//   이름: "불여우",
//   나이: 1000,
//   성별: "불",
//   멋짐: true,
//   "최고의 영화": ["반지의 제왕", "해리포터", "사자 그리고 옷장"],
//   "최고의 음식": [
//     {
//       이름: "붕어빵",
//       뚱뚱함: false
//     },
//     {
//       이름: "치즈버거",
//       뚱뚱함: true
//     }
//   ]
// }

// console.log('Hello');
// console.log('Hello');
// console.log('Hello');
// console.log('Hello');

// console.log(console);

// console.log('Greettings Firefox');
// console.log('Greettings Jun');
// console.log('Greettings Liyn');
// console.log('Greettings');
// console.log('Greettings');

// function sayHello(name, age) {
//   return `Hello ${name} you are ${age} years old`;
// }

// const greetFirefox = sayHello("Firefox", 1000);

// console.log(greetFirefox);

// const calculator = {
//   plus: function(a, b){
//     return a + b;
//   },
//   minus : function(a, b){
//     return a - b;
//   },
//   multiply : function(a, b){
//     return a * b;
//   },
//   divide : function(a, b){
//     return a / b;
//   },
//   square : function(a){
//     return a * a;
//   }
// }

// const plus = calculator.plus(5,5)
// const minus = calculator.minus(999999999999999999, 45468867661668)
// const multiply = calculator.multiply(9, 15)
// const divide = calculator.divide(1, 3)
// const square = calculator.square(9)
// console.log(plus)
// console.log(minus)
// console.log(multiply)
// console.log(divide)
// console.log(square)


// var coworkers = ["egoing", "leezche"];

// document.write(coworkers);
// console.log(coworkers);

// coworkers.push('duru')

// document.write(coworkers);
// document.write(coworkers.length);

// console.log(document.getElementById);

// const title = document.getElementById("title");

// console.log(title);

// const soldier = document.getElementById("soldier")

// console.error("Fuck");

// title.innerHTML = "Hi! Water Fox"
// title.style.color = "#E94B3C" //Cherry Tomato

// console.log(soldier)

// soldier.style.color = "#F0EDE5" //Coconut Milk

// soldier.innerText = "Test, just test"

// console.dir(document);

// document.title = "I own you now";


// title.innerHTML = "Hi! From JS";
// title.style.color = '#DD4132' //Fiesta
// console.dir(title);
// document.title = 'i won you now ㅋㅋ';

// const title = document.querySelector("#title");

// function handleClick(event){
//   console.log(event);
//   title.style.color = '#00539C'; //Princess Blue
// console.log("I have been resized")
// }

// window.addEventListener("resize", handleClick);

// const title = document.querySelector("#title");

// function handleClick(){
//   console.log(event);
//   console.log("I have been resized");
//   title.style.color = "red";
// }

// title.addEventListener("click", handleClick);

// if ('10' === 10) {
//   console.log("hi");
// } else if ("10" === "10") {
//   console.log("lalala");
// } else {
//   console.log("ho");
// }

// if(20 > 5 && "firefox" === "firefox"){
//   console.log("yes")
// } else {
//   console.log("no");
// }

// true && true = true;
// false && true = false;
// true && false = false;
// false && false = false;

// true || true = true;
// false || true = true;
// true || false = true;
// false || false = false;

// const age = prompt("How old are you");

// if (age >= 18 && age <= 21) {
//   console.log("you can drink but you should not")
// } else if (age > 21) {
//   console.log("go ahed")
// } else {
//   console.log("too young")
// }

// const title = document.querySelector("#title");

// const BASE_COLOR = "#034F84" /* Snorkel Blue */
// const OTHER_COLOR = "#B93A32" /* Aurora Red */

// function handleClick() {
//   const currentColor = title.style.color;
//   console.log(currentColor);
// }

// function init() {
//   title.style.color = BASE_COLOR;
//   title.addEventListener("click", handleClick);
// }

// init();

const title = document.querySelector("#title");
// title.innerHTML = "Hi! From JS";
// title.style.color = "red";
// document.title = "I own you now";

window.addEventListener("resize");